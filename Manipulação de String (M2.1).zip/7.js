let frase = "Estudando JavaScript todos os dias";
console.log(frase.slice(10)); // Exibe "JavaScript todos os dias", começando do índice 10 até o final
