let palavra = "Programação";
console.log(palavra.charAt(0)); // Exibe o primeiro caractere: "P"
console.log(palavra.charAt(palavra.length - 1)); // Exibe o último caractere: "o"
