let fruta = "Abacaxi";
console.log(fruta.charAt(3)); // Exibe o quarto caractere: "a"
