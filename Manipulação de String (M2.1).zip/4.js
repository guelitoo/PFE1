let linguagens = "JavaScript,Python,Ruby,C++";
console.log(linguagens.split(",")); // Exibe ["JavaScript", "Python", "Ruby", "C++"]
