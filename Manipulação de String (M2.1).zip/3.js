let mensagem = "Aprendendo JavaScript";
console.log(mensagem.slice(11)); // Exibe "JavaScript", a partir do índice 11
