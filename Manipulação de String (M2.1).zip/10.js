let texto = "Eu amo desenvolver aplicações web";
let palavras = texto.split(" ");
console.log(palavras.length); // Exibe o número de palavras: 5
