let sentenca = "Aprender a programar é divertido";
console.log(sentenca.split(" ")); // Exibe ["Aprender", "a", "programar", "é", "divertido"]
