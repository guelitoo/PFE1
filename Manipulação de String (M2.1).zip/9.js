let animais = "Cachorro,Gato,Elefante,Leão";
let animaisArray = animais.split(",");
console.log(animaisArray[1]); // Exibe o segundo elemento: "Gato"
