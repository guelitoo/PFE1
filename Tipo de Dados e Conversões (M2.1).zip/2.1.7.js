// Convertendo as strings para números
console.log(Number("123"));        // 123
console.log(Number("123.45"));     // 123.45
console.log(Number(""));           // 0
console.log(Number("abc"));        // NaN
console.log(Number("0"));          // 0

// Usando parseInt e parseFloat
console.log(parseInt("123.45"));   // 123
console.log(parseFloat("123.45")); // 123.45

// Diferença entre parseInt e parseFloat:
// parseInt converte para inteiro e ignora valores decimais.
// parseFloat converte para número com ponto flutuante (decimal).
